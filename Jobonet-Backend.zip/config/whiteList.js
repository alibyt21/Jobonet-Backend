export const superUserWhiteList = [
    "alibyt21@gmail.com",
    "tmarjani@gmail.com",
    "m.peidaie@gmail.com",
];
